"""Preprocessing: feature engineering, aggregations and summary tables."""
from __future__ import annotations

import numpy as np
import pandas as pd


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    """Create calculated columns useful for analysis."""
    df = df.copy()
    if {"sibsp", "parch"}.issubset(df.columns):
        df["family_size"] = df["sibsp"] + df["parch"] + 1
        df["is_alone"] = (df["family_size"] == 1).astype(int)
    if "age" in df.columns:
        df["age_group"] = pd.cut(
            df["age"],
            bins=[0, 12, 18, 35, 60, 120],
            labels=["child", "teen", "young_adult", "adult", "senior"],
        )
    if "fare" in df.columns:
        df["fare_bin"] = pd.qcut(df["fare"], q=4, labels=["low", "mid", "high", "premium"], duplicates="drop")
    return df


def filter_data(df: pd.DataFrame, sex: str | None = None, pclass: int | None = None) -> pd.DataFrame:
    """Filter data by sex and/or passenger class."""
    out = df.copy()
    if sex:
        out = out[out["sex"] == sex.lower()]
    if pclass:
        out = out[out["pclass"] == pclass]
    return out


def group_survival(df: pd.DataFrame, by: str) -> pd.DataFrame:
    """Aggregate survival rate by a categorical column."""
    grouped = (
        df.groupby(by, observed=True)["survived"]
        .agg(["mean", "count"])
        .rename(columns={"mean": "survival_rate", "count": "passengers"})
        .reset_index()
    )
    return grouped.sort_values("survival_rate", ascending=False)


def summary_table(df: pd.DataFrame) -> pd.DataFrame:
    """Return descriptive statistics for numeric columns."""
    return df.describe(include=[np.number]).T
