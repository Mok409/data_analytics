"""Visualization module — creates and saves charts into the images folder."""
from __future__ import annotations

import os
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

sns.set_theme(style="whitegrid", palette="deep")


def _save(fig, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=120, bbox_inches="tight")
    plt.close(fig)


def plot_histogram(df: pd.DataFrame, out: str) -> None:
    """Age distribution histogram."""
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.histplot(df["age"], bins=30, kde=True, ax=ax, color="#4C72B0")
    ax.set_title("Age Distribution of Passengers")
    ax.set_xlabel("Age")
    ax.set_ylabel("Count")
    _save(fig, out)


def plot_bar(df: pd.DataFrame, out: str) -> None:
    """Survival rate by passenger class."""
    data = df.groupby("pclass", observed=True)["survived"].mean().reset_index()
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.barplot(data=data, x="pclass", y="survived", ax=ax, hue="pclass", legend=False)
    ax.set_title("Survival Rate by Passenger Class")
    ax.set_ylabel("Survival Rate")
    ax.set_xlabel("Passenger Class")
    _save(fig, out)


def plot_pie(df: pd.DataFrame, out: str) -> None:
    """Passenger sex distribution."""
    counts = df["sex"].value_counts()
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.pie(counts.values, labels=counts.index, autopct="%1.1f%%",
           colors=sns.color_palette("deep"), startangle=90)
    ax.set_title("Passenger Sex Distribution")
    _save(fig, out)


def plot_box(df: pd.DataFrame, out: str) -> None:
    """Fare distribution by class."""
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.boxplot(data=df, x="pclass", y="fare", ax=ax, hue="pclass", legend=False)
    ax.set_title("Fare Distribution by Class")
    _save(fig, out)


def plot_scatter(df: pd.DataFrame, out: str) -> None:
    """Age vs Fare colored by survival."""
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.scatterplot(data=df, x="age", y="fare", hue="survived", alpha=0.7, ax=ax)
    ax.set_title("Age vs Fare (colored by Survival)")
    _save(fig, out)


def plot_heatmap(df: pd.DataFrame, out: str) -> None:
    """Correlation heatmap for numeric columns."""
    numeric = df.select_dtypes(include="number")
    fig, ax = plt.subplots(figsize=(9, 7))
    sns.heatmap(numeric.corr(), annot=True, fmt=".2f", cmap="coolwarm", ax=ax)
    ax.set_title("Correlation Heatmap")
    _save(fig, out)


def plot_line(df: pd.DataFrame, out: str) -> None:
    """Average survival rate across age groups (line chart)."""
    if "age_group" not in df.columns:
        return
    data = (
        df.groupby("age_group", observed=True)["survived"].mean().reset_index()
    )
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.lineplot(data=data, x="age_group", y="survived", marker="o", ax=ax, color="#C44E52")
    ax.set_title("Survival Rate by Age Group")
    ax.set_ylabel("Survival Rate")
    _save(fig, out)


def generate_all(df: pd.DataFrame, folder: str) -> None:
    """Generate every visualization required by the project."""
    plot_histogram(df, os.path.join(folder, "histogram.png"))
    plot_bar(df, os.path.join(folder, "bar_chart.png"))
    plot_pie(df, os.path.join(folder, "pie_chart.png"))
    plot_box(df, os.path.join(folder, "boxplot.png"))
    plot_scatter(df, os.path.join(folder, "scatter.png"))
    plot_heatmap(df, os.path.join(folder, "heatmap.png"))
    plot_line(df, os.path.join(folder, "line_chart.png"))
