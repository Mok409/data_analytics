"""Utility helpers for the Data Analytics project."""
from __future__ import annotations

import os
import pandas as pd


def load_dataset(path: str) -> pd.DataFrame:
    """Load a CSV dataset into a pandas DataFrame.

    Parameters
    ----------
    path : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Dataset not found at: {path}")
    return pd.read_csv(path)


def save_dataset(df: pd.DataFrame, path: str) -> None:
    """Save a DataFrame to CSV, creating parent folders if needed."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    df.to_csv(path, index=False)


def ensure_dir(path: str) -> None:
    """Create a directory if it does not exist."""
    os.makedirs(path, exist_ok=True)
