"""Data cleaning module for the Titanic dataset.

Handles missing values, duplicates, outliers (IQR), type correction,
column renaming, and inconsistent categorical values.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def rename_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Standardize column names to snake_case."""
    df = df.copy()
    df.columns = (
        df.columns.str.strip()
        .str.replace(" ", "_")
        .str.lower()
    )
    return df


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Fill or drop missing values sensibly."""
    df = df.copy()
    if "age" in df.columns:
        df["age"] = df["age"].fillna(df["age"].median())
    if "embarked" in df.columns:
        df["embarked"] = df["embarked"].fillna(df["embarked"].mode()[0])
    if "fare" in df.columns:
        df["fare"] = df["fare"].fillna(df["fare"].median())
    if "cabin" in df.columns:
        # Cabin has ~77% missing; convert to has_cabin flag then drop.
        df["has_cabin"] = df["cabin"].notna().astype(int)
        df = df.drop(columns=["cabin"])
    return df


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Drop exact duplicate rows."""
    return df.drop_duplicates().reset_index(drop=True)


def remove_outliers_iqr(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    """Remove rows whose value falls outside 1.5 * IQR for given columns."""
    df = df.copy()
    for col in columns:
        if col not in df.columns:
            continue
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        df = df[(df[col] >= low) & (df[col] <= high)]
    return df.reset_index(drop=True)


def correct_dtypes(df: pd.DataFrame) -> pd.DataFrame:
    """Cast columns to appropriate dtypes."""
    df = df.copy()
    if "survived" in df.columns:
        df["survived"] = df["survived"].astype(int)
    if "pclass" in df.columns:
        df["pclass"] = df["pclass"].astype("category")
    if "sex" in df.columns:
        df["sex"] = df["sex"].astype("category")
    if "embarked" in df.columns:
        df["embarked"] = df["embarked"].astype("category")
    return df


def normalize_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    """Standardize categorical text values (strip / lowercase)."""
    df = df.copy()
    for col in df.select_dtypes(include=["object", "category"]).columns:
        try:
            df[col] = df[col].astype(str).str.strip().str.lower()
        except Exception:
            pass
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Full cleaning pipeline."""
    df = rename_columns(df)
    df = handle_missing_values(df)
    df = remove_duplicates(df)
    df = normalize_categoricals(df)
    df = correct_dtypes(df)
    df = remove_outliers_iqr(df, ["fare"])
    return df
