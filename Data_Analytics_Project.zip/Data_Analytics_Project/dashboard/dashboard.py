"""Interactive Streamlit dashboard for the Titanic analytics project.

Run with:
    streamlit run dashboard/dashboard.py
"""
from __future__ import annotations

import os
import sys

import pandas as pd
import streamlit as st

# Allow importing the src package when running from repo root.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from src.data_cleaning import clean_data  # noqa: E402
from src.preprocessing import add_features, group_survival  # noqa: E402
from src.utils import load_dataset  # noqa: E402

st.set_page_config(page_title="Titanic Analytics Dashboard", layout="wide")


@st.cache_data
def get_data() -> pd.DataFrame:
    raw = load_dataset(os.path.join(ROOT, "data", "dataset.csv"))
    return add_features(clean_data(raw))


df = get_data()

st.title("🚢 Titanic Data Analytics Dashboard")
st.caption("Cleaning, processing and visualizing the Titanic passenger dataset.")

# ---------- Sidebar filters ----------
st.sidebar.header("Filters")
sex_opts = ["all"] + sorted(df["sex"].unique().tolist())
class_opts = ["all"] + sorted(df["pclass"].unique().tolist())
sex = st.sidebar.selectbox("Sex", sex_opts)
pclass = st.sidebar.selectbox("Passenger Class", class_opts)
age_range = st.sidebar.slider(
    "Age range", float(df["age"].min()), float(df["age"].max()),
    (float(df["age"].min()), float(df["age"].max())),
)

filtered = df.copy()
if sex != "all":
    filtered = filtered[filtered["sex"] == sex]
if pclass != "all":
    filtered = filtered[filtered["pclass"] == pclass]
filtered = filtered[(filtered["age"] >= age_range[0]) & (filtered["age"] <= age_range[1])]

# ---------- KPI cards ----------
c1, c2, c3, c4 = st.columns(4)
c1.metric("Passengers", f"{len(filtered):,}")
c2.metric("Survival Rate", f"{filtered['survived'].mean() * 100:.1f}%")
c3.metric("Average Age", f"{filtered['age'].mean():.1f}")
c4.metric("Average Fare", f"${filtered['fare'].mean():.2f}")

# ---------- Preview + missing ----------
with st.expander("Dataset Preview"):
    st.dataframe(filtered.head(20), use_container_width=True)

with st.expander("Missing Value Summary (raw data)"):
    raw = load_dataset(os.path.join(ROOT, "data", "dataset.csv"))
    st.dataframe(raw.isna().sum().rename("missing").to_frame())

# ---------- Charts ----------
st.subheader("Survival Rate by Passenger Class")
st.bar_chart(group_survival(filtered, "pclass").set_index("pclass")["survival_rate"])

st.subheader("Survival Rate by Sex")
st.bar_chart(group_survival(filtered, "sex").set_index("sex")["survival_rate"])

st.subheader("Age Distribution")
st.bar_chart(filtered["age"].value_counts(bins=20).sort_index())

st.subheader("Fare vs Age")
st.scatter_chart(filtered, x="age", y="fare", color="survived")

# ---------- Business insights ----------
st.subheader("💡 Business Insights")
insights = [
    f"Overall survival rate: **{df['survived'].mean() * 100:.1f}%**.",
    f"Females survived at **{df[df['sex'] == 'female']['survived'].mean() * 100:.1f}%** vs males at **{df[df['sex'] == 'male']['survived'].mean() * 100:.1f}%**.",
    f"First-class survival rate was **{df[df['pclass'] == 1]['survived'].mean() * 100:.1f}%**, third-class only **{df[df['pclass'] == 3]['survived'].mean() * 100:.1f}%**.",
    f"Passengers with a cabin recorded survived at **{df[df['has_cabin'] == 1]['survived'].mean() * 100:.1f}%** vs **{df[df['has_cabin'] == 0]['survived'].mean() * 100:.1f}%** without.",
    f"Average fare paid: **${df['fare'].mean():.2f}**, median: **${df['fare'].median():.2f}**.",
]
for i, line in enumerate(insights, 1):
    st.markdown(f"{i}. {line}")

# ---------- Download ----------
st.subheader("⬇️ Download Cleaned Dataset")
st.download_button(
    "Download CSV",
    data=filtered.to_csv(index=False).encode("utf-8"),
    file_name="titanic_cleaned.csv",
    mime="text/csv",
)
