"""Entry point — runs the full pipeline: clean, process, visualize, report."""
from __future__ import annotations

import os

from src.data_cleaning import clean_data
from src.preprocessing import add_features, group_survival, summary_table
from src.visualization import generate_all
from src.utils import load_dataset, save_dataset, ensure_dir

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_IN = os.path.join(ROOT, "data", "dataset.csv")
DATA_OUT = os.path.join(ROOT, "data", "dataset_cleaned.csv")
IMAGES = os.path.join(ROOT, "images")
REPORTS = os.path.join(ROOT, "reports")


def generate_insights(df) -> list[str]:
    """Return 10+ business insights derived from the cleaned dataset."""
    total = len(df)
    survival = df["survived"].mean() * 100
    female_rate = df[df["sex"] == "female"]["survived"].mean() * 100
    male_rate = df[df["sex"] == "male"]["survived"].mean() * 100
    class1 = df[df["pclass"] == 1]["survived"].mean() * 100
    class3 = df[df["pclass"] == 3]["survived"].mean() * 100
    avg_fare = df["fare"].mean()
    avg_age = df["age"].mean()
    cabin_rate = df[df["has_cabin"] == 1]["survived"].mean() * 100
    alone_rate = df[df["is_alone"] == 1]["survived"].mean() * 100
    family_rate = df[df["is_alone"] == 0]["survived"].mean() * 100
    top_embark = (
        df.groupby("embarked", observed=True)["survived"].mean().idxmax()
    )
    corr = df[["age", "fare", "survived"]].corr()

    return [
        f"Dataset contains **{total}** passengers after cleaning.",
        f"Overall survival rate is **{survival:.1f}%**.",
        f"Females survived at **{female_rate:.1f}%**, males at **{male_rate:.1f}%** — sex is the strongest predictor.",
        f"First-class survival **{class1:.1f}%** vs third-class **{class3:.1f}%** shows a strong class effect.",
        f"Passengers with a cabin record survived at **{cabin_rate:.1f}%** — cabin data likely correlates with wealth.",
        f"Traveling alone: **{alone_rate:.1f}%** survival vs **{family_rate:.1f}%** with family.",
        f"Embarkation port **'{top_embark}'** had the highest survival rate.",
        f"Average passenger age: **{avg_age:.1f}**; average fare: **${avg_fare:.2f}**.",
        f"Fare–survival correlation: **{corr.loc['fare', 'survived']:.2f}** (higher fare → higher survival).",
        f"Age–survival correlation: **{corr.loc['age', 'survived']:.2f}** (weak; children slightly favored).",
        "Recommendation: prioritize sex, class and fare as top features for any survival prediction model.",
    ]


def write_markdown_report(df, insights: list[str]) -> str:
    """Write the human-readable markdown summary."""
    path = os.path.join(REPORTS, "project_summary.md")
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Titanic Data Analytics — Project Summary\n\n")
        f.write("## Dataset Overview\n\n")
        f.write(f"- Cleaned rows: **{len(df)}**\n")
        f.write(f"- Columns: **{len(df.columns)}**\n\n")
        f.write("## Descriptive Statistics\n\n")
        f.write(summary_table(df).round(2).to_markdown() + "\n\n")
        f.write("## Survival by Class\n\n")
        f.write(group_survival(df, "pclass").to_markdown(index=False) + "\n\n")
        f.write("## Survival by Sex\n\n")
        f.write(group_survival(df, "sex").to_markdown(index=False) + "\n\n")
        f.write("## Business Insights\n\n")
        for i, line in enumerate(insights, 1):
            f.write(f"{i}. {line}\n")
    return path


def write_pdf_report(insights: list[str]) -> str:
    """Write a PDF version of the report using fpdf2."""
    from fpdf import FPDF
    path = os.path.join(REPORTS, "report.pdf")
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 18)
    pdf.cell(0, 10, "Titanic Data Analytics Report", ln=True)
    pdf.set_font("Helvetica", "", 11)
    pdf.ln(4)
    pdf.multi_cell(w=180, h=6, text=
        "This report summarizes data cleaning, processing and visualization "
        "of the Titanic passenger dataset, along with key business insights.",
    )
    pdf.ln(4)
    pdf.set_font("Helvetica", "B", 13)
    pdf.cell(0, 8, "Business Insights", ln=True)
    pdf.set_font("Helvetica", "", 11)
    for i, line in enumerate(insights, 1):
        clean = (line.replace("**", "")
                     .replace("\u2014", "-")
                     .replace("\u2013", "-")
                     .replace("\u2192", "->"))
        clean = clean.encode("latin-1", "replace").decode("latin-1")
        pdf.multi_cell(w=180, h=6, text=f"{i}. {clean}")
    pdf.ln(4)
    pdf.set_font("Helvetica", "B", 13)
    pdf.cell(0, 8, "Visualizations", ln=True)
    for img in ["histogram.png", "bar_chart.png", "heatmap.png", "boxplot.png"]:
        img_path = os.path.join(IMAGES, img)
        if os.path.exists(img_path):
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 12)
            pdf.cell(0, 8, img.replace(".png", "").replace("_", " ").title(), ln=True)
            pdf.image(img_path, w=180)
    pdf.output(path)
    return path


def main() -> None:
    ensure_dir(IMAGES)
    ensure_dir(REPORTS)

    print("Loading dataset...")
    raw = load_dataset(DATA_IN)
    print(f"  Raw shape: {raw.shape}")

    print("Cleaning data...")
    cleaned = clean_data(raw)
    print(f"  Cleaned shape: {cleaned.shape}")

    print("Feature engineering...")
    processed = add_features(cleaned)

    print("Saving cleaned dataset...")
    save_dataset(processed, DATA_OUT)

    print("Generating visualizations...")
    generate_all(processed, IMAGES)

    print("Building insights...")
    insights = generate_insights(processed)

    print("Writing markdown report...")
    md = write_markdown_report(processed, insights)
    print(f"  -> {md}")

    print("Writing PDF report...")
    pdf = write_pdf_report(insights)
    print(f"  -> {pdf}")

    print("Done ✅")


if __name__ == "__main__":
    main()
